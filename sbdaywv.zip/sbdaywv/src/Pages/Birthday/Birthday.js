import React, { useState } from 'react';
import './birthday.scss';

const Birthday = () => {
    const [isOpen, setIsOpen] = useState(false);

    const handleCardClick = () => {
      setIsOpen(true);
    };
  
    return (
      <div className="birthday-page">
        <div className={`card ${isOpen ? 'open' : ''}`} onClick={handleCardClick}>
          <div className="card-front">
            <h2>Click to Open</h2>
          </div>
          <div className="card-inside">
            <h1>🎉 Happy Birthday! 🎂</h1>
          </div>
        </div>
  
        {isOpen && (
          <div className="balloons">
            {[...Array(20)].map((_, i) => (
              <div key={i} className="balloon" />
            ))}
          </div>
        )}
      </div>
    );
}

export default Birthday





